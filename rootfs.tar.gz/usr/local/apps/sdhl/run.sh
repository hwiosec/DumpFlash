#!/bin/bash

nohup /mnt/jvm/siege -Xms8M -Xmx16M -classpath lib/json_simple-1.1.jar:lib/slf4j-api-1.4.3.jar:lib/slf4j-nop-1.4.3.jar -Djava.util.logging.config.file=logging.properties -jar selfHealing.jar -al=/usr/local/apps/sdhl/ &
