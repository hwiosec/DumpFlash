#!/bin/sh
#

SSCEP=$SIMULATOR_ROOT/sbin/sscep
SSCEP_CONFIG=$SIMULATOR_ROOT/etc/scep/conf/sscep.conf
CA_CERT=$SIMULATOR_ROOT/media/config/ca-certs
DEV_CERT=$SIMULATOR_ROOT/media/config/dev-certs
CHMOD=/bin/chmod

echo " [!] REQUEST: $SSCEP enroll -v -d -u "${SCEPURL}" -S sha1 -c $CA_CERT/ca.crt-0 -e $CA_CERT/ca.crt-0 -k $DEV_CERT/device.key -r $DEV_CERT/device.csr -l $DEV_CERT/device.crt"
$SSCEP enroll -v -d -u "${SCEPURL}" -S sha1 -c $CA_CERT/ca.crt-0 -e $CA_CERT/ca.crt-0 -k $DEV_CERT/device.key -r $DEV_CERT/device.csr -l $DEV_CERT/device.crt

if [ -f $DEV_CERT/device.crt ]; then
	$CHMOD 600 $DEV_CERT/device.crt
	cat $DEV_CERT/device.crt > $DEV_CERT/device.pem
	cat $DEV_CERT/device.key >> $DEV_CERT/device.pem
fi
