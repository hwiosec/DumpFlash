#!/bin/sh

SSCEP=$SIMULATOR_ROOT/sbin/sscep
SSCEP_CONFIG=$SIMULATOR_ROOT/etc/scep/conf/sscep.conf
CA_CERT=$SIMULATOR_ROOT/media/config/ca-certs
CA_FILE=$CA_CERT/ca.crt
CHMOD=/bin/chmod

if [ ! -f $SSCEP_CONFIG ]; then

    echo -e "Cowardly refusing to run sscep with out its config."
    echo -e "Please ensure config file is in $SSCEP_CONFIG\n"

    exit 1

fi

if [ -f $SSCEP ]; then

    echo -e " [!] Found sscep binary in $SSCEP \n"
	echo " [!] Starting scep for ${MAC}-${SERIAL}"
    echo " [!] Command: $SSCEP getca -f $SSCEP_CONFIG"
    $SSCEP getca -u "${SCEPURL}" -c $CA_FILE -f $SSCEP_CONFIG
    $CHMOD 600  $CA_CERT/*

else

    echo "No sscep binary! please compile from source"

    exit 2
fi
