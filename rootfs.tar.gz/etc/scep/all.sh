#!/bin/sh
#
sh clean.sh
sh 01-get-ca.sh
SCEP_EXIT_CODE=$?
if [ $SCEP_EXIT_CODE -eq 0 ]; then
    sh 011-validate-root-crt.sh
    SCEP_EXIT_CODE=$?
fi
if [ $SCEP_EXIT_CODE -eq 0 ]; then
    sh 02-gen-request.sh
    SCEP_EXIT_CODE=$?
fi
if [ $SCEP_EXIT_CODE -eq 0 ]; then
    sh 03-enroll.sh
    SCEP_EXIT_CODE=$?
fi
echo SCEP_EXIT_CODE=$SCEP_EXIT_CODE
return $SCEP_EXIT_CODE

