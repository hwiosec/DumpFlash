#!/bin/sh

#vars
OPENSSL_CONF=$SIMULATOR_ROOT/media/config/client.cnf
OPENSSL=$SIMULATOR_ROOT/bin/openssl
CA_CERT=$SIMULATOR_ROOT/media/config/ca-certs
INSTALLED_CA_CERTS=$SIMULATOR_ROOT/etc/scep/ca-certs/$SCEPSERVERTYPE

if [ ! -f $OPENSSL_CONF ]; then

    echo -e "Cowardly refusing to run openssl without its config."
    echo -e "Please ensure config file is in $OPENSSL_CONF"

    exit 3
fi

if [ -f $OPENSSL ]; then

    echo " [!] Command: $OPENSSL verify -CAfile $CA_CERT/ca.crt-1 $CA_CERT/ca.crt-0 "

    VERIFY_RESULT=$($OPENSSL verify -CAfile $CA_CERT/ca.crt-1 $CA_CERT/ca.crt-0)

    echo "Result $VERIFY_RESULT"

    if [ "$VERIFY_RESULT" != "$CA_CERT/ca.crt-0: OK" ]; then

        echo -e "New Root certificate was not validated"

        exit 4

    fi

    echo " [!] Command: $OPENSSL verify -CAfile $INSTALLED_CA_CERTS/ca.crt-1 $INSTALLED_CA_CERTS/ca.crt-0 "

    VERIFY_RESULT=$($OPENSSL verify -CAfile $INSTALLED_CA_CERTS/ca.crt-1 $INSTALLED_CA_CERTS/ca.crt-0)

    echo "Result $VERIFY_RESULT"

    if [ "$VERIFY_RESULT" != "$INSTALLED_CA_CERTS/ca.crt-0: OK" ]; then

        echo -e "Pre-installed Root certificate was not validated"

        exit 5

    fi

    echo " [!] Command: $OPENSSL x509 -in $CA_CERT/ca.crt-0 -noout -fingerprint "

    FP_0=$($OPENSSL x509 -in $CA_CERT/ca.crt-0 -noout -fingerprint)

    echo " [!] Command: $OPENSSL x509 -in $INSTALLED_CA_CERTS/ca.crt-0 -noout -fingerprint "

    FPN_0=$($OPENSSL x509 -in $INSTALLED_CA_CERTS/ca.crt-0 -noout -fingerprint)

    if [ "$FP_0" != "$FPN_0" ]; then

        echo -e "New Certificate 0 did not match the new Pre-installed certificate 0"

        exit 6

    fi

    echo " [!] Command: $OPENSSL x509 -in $CA_CERT/ca.crt-1 -noout -fingerprint "

    FP_1=$($OPENSSL x509 -in $CA_CERT/ca.crt-1 -noout -fingerprint)

    echo " [!] Command: $OPENSSL x509 -in $INSTALLED_CA_CERTS/ca.crt-1 -noout -fingerprint "

    FPN_1=$($OPENSSL x509 -in $INSTALLED_CA_CERTS/ca.crt-1 -noout -fingerprint)

    if [ "$FP_1" != "$FPN_1" ]; then

        echo -e "New Certificate 1 did not match the new Pre-installed certificate 1"

        exit 7

    fi
else

    echo -e "No openssl found. please check that its installed, if not change variable to location!"

    exit 8

fi
