#!/bin/sh

CA_CERT=$SIMULATOR_ROOT/media/config/ca-certs
DEV_CERT=$SIMULATOR_ROOT/media/config/dev-certs
CLIENT_CONF=$SIMULATOR_ROOT/media/config/client.cnf

# Clean files
rm -f $CLIENT_CONF
rm -rf $CA_CERT
rm -rf $DEV_CERT

# Create folders and empty files
mkdir -p $CA_CERT
mkdir -p $DEV_CERT
touch $CLIENT_CONF
