#!/bin/sh

#vars
PREFIX=device
KEYBITS=2048
OPENSSL_CONF=$SIMULATOR_ROOT/media/config/client.cnf
CHMOD=/bin/chmod
OPENSSL=$SIMULATOR_ROOT/bin/openssl
DEVCERTS=$SIMULATOR_ROOT/media/config/dev-certs

if [ ! -f $OPENSSL_CONF ]; then

    echo -e "Cowardly refusing to run openssl without its config."
    echo -e "Please ensure config file is in $OPENSSL_CONF\n"

    exit 1

fi

# TODO For reader - fill in config with MAC and SERIAL MAC is uid and SERIAL is
# challenge. 
#
cat << EOF >> $OPENSSL_CONF

[ req ]
prompt = no
default_bits        = 2048
distinguished_name  = req_distinguished_name
attributes      = req_attributes
req_extensions = v3_req

[ req_distinguished_name ]
CN=${MAC}

[ req_attributes ]
challengePassword       = ${SERIAL}
[v3_req ]

# Extensions to add to a certificate request

basicConstraints = CA:FALSE
keyUsage = Digital Signature, Key Encipherment
extendedKeyUsage = clientAuth

EOF

if [ -f $OPENSSL ]; then

    echo " [!] Command: $OPENSSL genrsa -out $DEVCERTS/$PREFIX.key $KEYBITS"

    $OPENSSL genrsa -out $DEVCERTS/$PREFIX.key $KEYBITS
    $CHMOD 600 $DEVCERTS/$PREFIX.key

else

    echo -e "No openssl found. please check that its installed, if not change varible to location!"

    exit 1

fi

if [ ! -f $DEVCERTS/$PREFIX.key ]; then

    echo "No private key! I cant not go on."

    exit 1

else
    # Make request
    echo " [!] Command: openssl req -new -key $DEVCERTS/$PREFIX.key -out $DEVCERTS/$PREFIX.csr -config $OPENSSL_CONF -sha384"
    openssl req -new -key $DEVCERTS/$PREFIX.key -out $DEVCERTS/$PREFIX.csr -config $OPENSSL_CONF -sha384
    $CHMOD 600 $DEVCERTS/$PREFIX.csr

fi
